#include <stdio.h>

void function1();
void function2();
void function3();

void main(){
    function1();
    function2();
    function3();
}