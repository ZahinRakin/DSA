#include <stdio.h>

void function1() {
    printf("This is function 1\n");
}
