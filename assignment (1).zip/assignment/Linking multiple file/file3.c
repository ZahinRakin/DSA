#include <stdio.h>

void function3() {
    printf("This is function 3\n");
}