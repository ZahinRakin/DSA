#include <stdio.h>

void function2() {
    printf("This is function 2\n");
}